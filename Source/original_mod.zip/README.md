# Block Unwanted Minutiae
This mod blocks some unwanted messages, alerts, letters, and misc features that Rimworld has, with mod settings enabled so you can toggle off any you don't want blocked.

See the workshop page for details -> https://steamcommunity.com/sharedfiles/filedetails/?id=2266225921
